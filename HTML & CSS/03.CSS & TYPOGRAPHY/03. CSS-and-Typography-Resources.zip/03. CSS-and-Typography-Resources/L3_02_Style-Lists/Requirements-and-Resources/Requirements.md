# 02 - Style Lists
------
Problems for in-class lab for the [�HTML & CSS�](https://softuni.bg/trainings/2375/html-and-css-may-2019) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1234/CSS-Typography).

## Tasks
* Create an **index.html** file with **Style Lists** title 
  * Use **font-family: Helvetica, sans-serif**, with **font-size: 16px** and **line-height: 1.5**
* Add section with two articles inside (for each list)
 * Each article must have a **h2** heading
 * Use **ul** for unordered list
	* Add four list items
 * Use **ol reversed** for ordered reversed list
	* Add three **list** items
