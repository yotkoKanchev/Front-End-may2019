# 06 - Tags Cardio - Table
------
Problems for in-class lab for the [“Web Fundamentals - HTML 5”](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS).

## Constraints
 * Change the document **title** to *Checkout tablе*
 * Use **h2** tag for heading
 * Use **table** tag to create a table
 * Use **tr** tag for rows
 * Use **th** and **td** tags for columns 
 * Use **span** tag with value **checked** for checked items
