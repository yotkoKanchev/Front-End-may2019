﻿# 03 - Grid Gallery
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2259/css-advanced-march-2019) course @ **SoftUni**.

## Tasks
* Create **index.html** and **style.css** files
* Use **img** tags to display the pictures
* Set to the body display property **grid**
* Define your grid. Your gallery does not have to look like the screenshot.
* Redefine the grid using Media Queries when the screen has 800px width.
